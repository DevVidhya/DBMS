import mysql.connector


mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    passwd="adwaith123",
    database="dbmslab1"
)

mycursor=mydb.cursor()

# mycursor.execute("CREATE database dbmslab1")
# mycursor.execute("""
#     create table reservation(
#         seatno int, 
#         name varchar(20),
#         src varchar(20),
#         dest varchar(20),
#         primary key(seatno)
#     )
# """)

while(1):
    print("Enter your choice")
    print("1-Insert 2-Find 3-Update 4-Delete 5-Quit")

    choice = int(input("Enter your choice: "))

    if(choice==1):
        seatno = input("Enter passenger seatno: ")
        name = input("Enter passenger name: ")
        src = input("Enter passenger src: ")
        dest = input("Enter passenger dest: ")
        mycursor.execute("insert into reservation (seatno, name, src, dest) values (%s, %s, %s, %s)", (seatno, name, src, dest))
        mydb.commit()

    elif(choice==2):
        name = input("Enter passenger name: ")
        mycursor.execute("select * from reservation where name = %s", (name,))
        namelist=mycursor.fetchall()

        for x in namelist:
            print(x)
        
        if(len(namelist)==0):
            print("No records with given name")
        
    elif(choice==3):
        seatno = input("Enter seat no: ")
        dest = input("Enter new Destination: ")
        mycursor.execute("update reservation set dest=%s where seatno=%s", (dest,seatno))
        mydb.commit()

    elif(choice==4):
        seatno = input("Enter seat no: ")
        mycursor.execute("delete from reservation where seatno=%s", (seatno,))
        mydb.commit()
        
    else:
        break


