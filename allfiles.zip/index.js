var mysql = require('mysql');
var moment = require('moment');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "adwaith123",
  database: "dbmslab2"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");

    //   con.query("CREATE DATABASE dbmslab2", function (err, result) {
    //     if (err) throw err;
    //     console.log("Database created!!");
    //   });

    // let q= `CREATE TABLE transactions(
    //     id int primary key auto_increment,
    //     user_id int ,
    //     amt int,
    //     msg varchar(20),
    //     time timestamp
    // )`

    // con.query(q, function (err, result) {
    //     if (err) throw err;
    //     console.log("Table created!!");
    // });

    // 1 - register new user
    // 2 - display balance
    // 3 - credit
    // 4 - debit
    // 5 - transfer
    // 6 - print user transactions

    let op=6;

    if(op==1){
        let vals=[["rahul", 3000]];
        let sql = "INSERT INTO bankacc (name, balance) VALUES ?";
        con.query(sql,[vals], function(err, result){
            if(err){
                console.log("error in inserting");
            }
            else{
                console.log("number of records inserted: ", result.affectedRows);
            }
        });
    }
    else if(op==2){
        let id = 1;
        let sql = `SELECT * FROM bankacc where id =${id}`;
        con.query(sql, function (err, result, fields) {
            if (err) throw err;
            console.log(result);
        });
    }
    else if(op==3){
        let id = 1;
        let incre_val = 50;
        let sql = `UPDATE bankacc set balance=balance+${incre_val} where id =${id}`;
        con.query(sql, function (err, result, fields) {
            if (err) throw err;
            console.log(result);
        });

        // let ts=moment(Date.now()).format('YYYY-MM-DD HH:mm:ss');
        sql = `INSERT INTO transactions (user_id, amt, msg, time) values 
                (${id}, ${incre_val}, "credit", NOW())`;
        con.query(sql, function (err, result, fields) {
            if (err) throw err;
            console.log(result);
        });
    }
    else if(op==4){
        let id = 1;
        let decre_val = 100;
        let sql = `UPDATE bankacc set balance=balance-${decre_val} where id =${id}`;
        con.query(sql, function (err, result, fields) {
            if (err) throw err;
            console.log(result);
        });

        sql = `INSERT INTO transactions (user_id, amt, msg, time) values 
                (${id}, ${decre_val}, "debit", NOW())`;
        con.query(sql, function (err, result, fields) {
            if (err) throw err;
            console.log(result);
        });
    }
    else if(op==5){
        let srcid=1;
        let destid=2;
        let transfer_amount=200;

        let sql = `UPDATE bankacc set balance=balance-${transfer_amount} where id =${srcid}`;
        con.query(sql, function (err, result, fields) {
            if (err) throw err;
            console.log(result);
        });

        sql = `INSERT INTO transactions (user_id, amt, msg, time) values 
            (${srcid}, ${transfer_amount}, "debit", NOW())`;
        con.query(sql, function (err, result, fields) {
            if (err) throw err;
            console.log(result);
        });

        sql = `UPDATE bankacc set balance=balance+${transfer_amount} where id =${destid}`;
        con.query(sql, function (err, result, fields) {
            if (err) throw err;
            console.log(result);
        });

        sql = `INSERT INTO transactions (user_id, amt, msg, time) values 
                (${destid}, ${transfer_amount}, "debit", NOW())`;
        con.query(sql, function (err, result, fields) {
            if (err) throw err;
            console.log(result);
        });
    }
    else if(op==6){
        let id = 1;
        let sql = `SELECT * FROM transactions where user_id =${id} order by time DESC`;
        con.query(sql, function (err, result, fields) {
            if (err) throw err;
            console.log(result);
        });


    }

});
